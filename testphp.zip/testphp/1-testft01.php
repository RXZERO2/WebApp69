<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function</title>
</head>
<body>
    <H2>First time for PHP</H2>
    <?php
        /* Defining a PHP Function */
        function whileMessage(): void{
            echo "You are really a nice person, Have a nice time!";
        }

        /* Calling a PHP Function */
        whileMessage();
        ?>

</body>
</html>