<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Function calls</title>
</head>
<body>
    <H2>Dynamic Function calls</H2>
    <?php
        function sayHello(){
            echo "Hello<br />";
        }

        $function_holder = "sayHello";
        $function_holder();
        sayHello();
    ?>

</body>
</html>